from Crypto.Util.number import *
from hashlib import sha256
import socketserver
import signal
import os
import string
import random
from sympy.ntheory.modular import crt 
from line_profiler import LineProfiler


flag = os.getenv('DASFLAG')

def euclide_ext(a, b):  
    x, xx, y, yy = 1, 0, 0, 1
    while b:
        q = a // b
        a, b = b, a % b
        x, xx = xx, x - xx * q
        y, yy = yy, y - yy * q
    return x, y, a

class Montgomery:
    n: int
    k: int
    r: int
    r_inv: int
    n_inv: int
    
    def __init__(self, n, k):
        self.n = n
        self.k = k
        self.r = 2 ** k
        self.r_inv, self.n_inv, gcd = euclide_ext(self.r, self.n)
        self.n_inv = -self.n_inv  
        if gcd != 1:
            raise ValueError("gcd(r,n) must be 1")
        if self.r * self.r_inv - self.n * self.n_inv != 1:
            raise ValueError(
                f"For ({self.r} that created from {2} ** {k},{n}) doesn't exists diophantine equation decision"
            )
        self.r_inv = self.r_inv % self.n

    def mon_pro(self, a_n, b_n):
        t = a_n * b_n
        u = (t + (t * self.n_inv % self.r) * self.n) >> self.k
        if u > self.n:
            u -= self.n
        return u

    def mon_exp(self, a: int, e: int):
        a = a * self.r % self.n
        x = self.r % self.n
        for i in reversed(range(0, e.bit_length())):
            x= self.mon_pro(x, x)
            if (e & (1 << i))  :
                x= self.mon_pro(x, a)
        return self.mon_pro(x, 1)






class Task(socketserver.BaseRequestHandler):
    def _recvall(self):
        BUFF_SIZE = 2048
        data = b''
        while True:
            part = self.request.recv(BUFF_SIZE)
            data += part
            if len(part) < BUFF_SIZE:
                break
        return data.strip()

    def send(self, msg, newline=True):
        try:
            if newline:
                msg += b'\n'
            self.request.sendall(msg)
        except:
            pass

    def recv(self, prompt=b'> '):
        self.send(prompt, newline=False)
        return self._recvall()

    def handle(self):
        bits=1024
        p=getPrime(bits)
        q=getPrime(bits)
        e=getPrime(bits-10)
        n=p*q
        print(p,",",q)
        print(flag)
        P=Montgomery(p,bits)
        Q=Montgomery(q,bits)
        self.send(str((n,e)).encode())
        signal.alarm(300)
        for i in range(600):
            lp = LineProfiler()
            lp.add_function(Q.mon_pro)
            lp_exp = lp(P.mon_exp)
            lq_exp = lp(Q.mon_exp)
            self.send(b"leave message 4 me",newline=False)
            m=int(self.recv())
            cp=lp_exp(m,e)
            cq=lq_exp(m,e)
            c=crt([p,q],[cp,cq])
            d={}
            for i in lp.code_map:
                for j in lp.code_map[i]:
                    d[j]=(lp.code_map[i][j]['total_time'],lp.code_map[i][j]['nhits'])
            self.send(str(d).encode())
        self.send(b"can you break me?",newline=False)    
        guess=int(self.recv())
        if guess in {p,q}:
            self.send(flag.encode())
        else:
            self.send(b"sorry~")
        exit            

class ThreadedServer(socketserver.ThreadingMixIn, socketserver.TCPServer):
    pass


class ForkedServer(socketserver.ForkingMixIn, socketserver.TCPServer):
    pass


if __name__ == "__main__":
    HOST, PORT = '0.0.0.0', 9999
    print("HOST:POST " + HOST+":" + str(PORT))
    server = ForkedServer((HOST, PORT), Task)
    server.allow_reuse_address = True
    server.serve_forever()
