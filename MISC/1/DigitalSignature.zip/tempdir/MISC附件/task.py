from web3 import Web3
from eth_account.messages import encode_defunct
from Crypto.Util.number import bytes_to_long


def SignMessage(Message: str, PrivateKey: str) -> dict:
    Provider = Web3()
    Temp = encode_defunct(text=Message)
    SignedMessage = Provider.eth.account.sign_message(Temp, private_key=PrivateKey)
    SignedMessageHash = SignedMessage.messageHash.hex()
    SignedMessageSignature = SignedMessage.signature.hex()
    return {"Message": Message, "SignedMessageHash": SignedMessageHash, "SignedMessageSignature": SignedMessageSignature}


def CreateNewAccount() -> tuple:
    Provider = Web3()
    Keys = Provider.eth.account.create()
    Address = Provider.toChecksumAddress(Keys.address)
    PrivateKey = hex(bytes_to_long(Keys.privateKey))
    return (Address, PrivateKey)


(Address, PrivateKey) = CreateNewAccount()
SignData = SignMessage("Find out the signer. Flag is account address that wrapped by DASCTF{}.", PrivateKey)
print(f"MessageHash:{SignData['SignedMessageHash']}\nSignature:{SignData['SignedMessageSignature']}")

'''
MessageHash:0x61a78e3c572c1615a6ddd0a0e20157d22b72b8c217cb247318f2c791f4ab6b85
Signature:0x019c4c2968032373cb8e19f13450e93a1abf8658097405cda5489ea22d3779b57815a7e27498057a8c29bcd38f9678b917a887665c1f0d970761cacdd8c41fb61b
'''
